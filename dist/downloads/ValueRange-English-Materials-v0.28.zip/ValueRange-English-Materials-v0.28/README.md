# ValueRange — English materials

Public demo v0.28 · Prepared September 18, 2026

Turn company valuations into on-chain LP strategies with AI.

ValueRange is the product identity; CIRCLE is the current case study. Earlier demo releases were named CIRCLE Lab.

This package contains the English supporting materials selected for the CIRCLE demonstration. Original financial data, dates and AI input/output hashes are preserved. Translations are presentation copies, not new research or model runs. Complete private Skills, prompts and production orchestration are not included.

## Open the demo

[English public demo](https://valuerange-demo.netlify.app/?lang=en#overview) · [Chinese public demo](https://valuerange-demo.netlify.app/?lang=zh#overview)

The public demo opens in English at the bare URL. Use ?lang=zh or the header control for Chinese. No local server is needed. The guides retain their dated local development and validation history. This materials archive is not the application or a public deployment. The demo's top-right English / Chinese selector also switches the supporting document reader without resetting simulation choices.

A fresh open or refresh starts at the overview with default inputs; in-page steps and language switching retain the current scenario. The Run page has one path selector and a synchronized preview. Repeated trading and annual fee reinvestment are separate controls.

## Read in this order

1. [AI workflow and evidence](guides/AI_WORKFLOW.md)
2. [Valuation model](evidence/valuation.md) and [financial inputs](evidence/valuation_inputs.md)
3. [Historical AI proposal](evidence/ai_candidate.md) and [expanded AI reasoning](evidence/ai_decision.md)
4. [Dated opening price and case defaults](guides/DEMO_REFERENCE.md), then [simulation, fee APR, reinvestment and ROI methodology](guides/SIMULATION_METHODS.md)
5. [Daily fact bridge](evidence/bridge.md), [operating conclusion](evidence/monitor.md) and [PNL reconciliation](evidence/pnl_latest.md)
6. [Future Vault and Agent products](guides/FUTURE_PREVIEWS.md)

## Research replays

- [September 14](evidence/research-20260914.md)
- [September 15](evidence/research-20260915.md)
- [September 16](evidence/research-20260916.md)

## Machine-readable evidence

- [AI candidate archive](records/ai-evidence.json)
- [Workflow evidence](records/workflow-evidence.json)
- [Hypothetical improvement inputs](records/ai-input-improve.json)
- [Hypothetical pressure inputs](records/ai-input-pressure.json)
- [Sources and SHA-256 manifest](manifest.json)

## Scope and validation

[Validation](guides/VALIDATION.md) · [Localization and maintenance](guides/LOCALIZATION.md)

Simulated outcomes, historical strategy proposals, actual monitored positions and future product concepts remain distinct. Fee APR is not portfolio ROI. All selected translated excerpts are included; their scope is the same as the demo's selected business sections.
