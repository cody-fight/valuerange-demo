# Localization and release notes

Version 0.26 · User-facing controls and strategy explanations updated 2026-09-18

## Storage

All files remain inside the existing Stocklana demo directory. The production workspace is a read-only source. The initial Chinese-only demo is backed up at `versions/v0.9-before-bilingual/dist/`; the previous local release is backed up at `versions/v0.20-before-scenario-context/`.

| Location | Purpose |
|---|---|
| `dist/` | One static application, one state model and one calculation engine |
| `dist/locales/en.json` | Offline English UI catalog, including dynamic chart and scenario text |
| `dist/locales/locale.mjs` | Presentation-only translation and locale selection |
| `dist/locales/locale.css` | Language switch and long-English-label layout adjustments |
| `dist/data/*.json` | Unmodified canonical demo evidence and numeric data |
| `dist/data/en/documents.json` | English excerpts used by the evidence dialogs |
| `dist/data/en/*evidence.json`, `ai-input-*.json` | Translated business copies, with original and translation metadata |
| `docs/en/` | Human-readable English walkthrough, AI architecture and methodology |
| `docs/en/evidence/` | Ten complete translations of the existing selected demo excerpts |
| `docs/localization/` | Source-text inventory, reviewed translations, additions and provenance manifest |
| `exports/english-v0.26/` | Standalone English evidence and explanatory materials |
| `dist/downloads/ValueRange-English-Materials-v0.25.zip` | Downloadable copy of that English materials pack |

Chinese remains the canonical source for existing evidence. English filenames are readable aliases, not renamed production sources. The manifest keeps the original source names and hashes alongside English aliases and translation hashes.

## Language behavior

`?lang=en` and `?lang=zh` explicitly select a language. For this public release, a URL without a language parameter opens in English, even when an older browser preference was Chinese. In-page language changes update the URL. The URL's page hash is retained. The English / Chinese control updates presentation without recomputing financial inputs or replacing the separate candidate preview. Evidence readers select the matching translated document; Vault and Agent previews retain their local configuration.

The new lifecycle view also contains paired Chinese/English strings selected by the same locale setting. The catalog maps original message templates to reviewed English text. Number strings are substituted without reformatting or recalculation. IDs, data attributes, chart coordinates, links and machine statuses remain unchanged. Unknown messages retain their source text so missing coverage is visible during review rather than silently omitted.

English evidence is exported from local Markdown with its own SHA-256. Original file/excerpt and AI input/output hashes continue to identify the original records. The application checks excerpt-version identity before using the bundle; a changed source excerpt requires a translation refresh. UI copies describe translation as presentation, not a new AI or research run.

## Updating translations

From the demo root:

```text
python -X utf8 scripts/build_locales.py
python -X utf8 scripts/build_english_evidence.py
node scripts/collect_locale_ui.mjs
python -X utf8 scripts/extract_locale_ui.py --check
node scripts/check_flow_copy.mjs
python -X utf8 scripts/check_flow_copy.py
node --test tests/*.test.mjs
python -X utf8 scripts/package_english_materials.py
```

The original ordered `ui-source.json` inventory is frozen because reviewed TSV rows refer to its indices. Do not overwrite it when checking changes. Use `--check` to generate `ui-missing.json`; add new source templates and translations to `ui-extra.json`, then rebuild. Catalog compilation validates numbered placeholders.

For a changed source document, review and translate the changed content before re-exporting. Preserve source dates and calculations. Update translation dates/version metadata deliberately; rebuilding a bundle alone is not a research refresh.

## Review scope

This release preserves the v0.19 lifecycle and all financial outputs. It explains same-time comparison and separates measured asset/fee differences from hypotheses to review. The path selector now preserves the chosen target and duration. The instantaneous annualized fee equivalent appears only in the explanation drawer. The main case uses the dated $92.02 close; archived analytical defaults retain $88.53. Tests cover equal-capital initialization, P&L reconciliation, numeric placeholder integrity, original/translation hashes, financial table values and language-independent results. Guides describe the current path presets and year-four review; original business evidence is retained unchanged.

Coverage includes the guided strategy pages, live evidence, AI & research, the future landing page and its Vault/Agent previews, plus document readers and detailed workflow/AI views. English tables and long valuation diagrams retain horizontal scrolling inside their own containers.

This release is local. No public deployment, GitHub publication, new model generation, wallet operation or production workflow was performed for localization.

The header Reset demo button restores all simulation inputs, review drafts, observation cursors and Vault/Agent preview state, while preserving language and real evidence. The adjacent information button lists the fixed starting configuration.

## Fresh visits and a single path selector · v0.26

Each new document load or refresh starts at the overview with the default five-year, $85 repeated-swing case, even when the copied URL contains a step fragment. Restoring a cached document also starts a new case. The language query is retained; moving between steps or switching language inside the current document preserves the scenario. This demo intentionally favors a reproducible first visit over resuming a previous experiment.

Run it and Compare share all seven path templates and labels. The Run page uses one selector and a preview generated from the same price knots as the calculation engine. Duration and target remain independent. Loaded review examples have their own selected label until replaced. The settings drawer no longer contains a second price-path selector.

“Buy back and reopen LPs when conditions are met” controls repeated trading with available portfolio funds. Sale proceeds may buy shares at a pullback trigger and fund LPs again on recovery. When off, existing LPs finish at their exit conditions without reopening under the original rules. “Reinvest fees annually” separately controls earned fees: add them to eligible in-range LPs at year-end, or retain them as cash. A valuation revision follows its new allocation policy.

The next step is “Next: adjust valuation & positions.” It changes the valuation assumptions and allocation at the review date, while the market-price assumption remains independent.

 Localization and release notes

Version 0.25 · User-facing controls and strategy explanations updated 2026-09-18

## Storage

All files remain inside the existing Stocklana demo directory. The production workspace is a read-only source. The initial Chinese-only demo is backed up at `versions/v0.9-before-bilingual/dist/`; the previous local release is backed up at `versions/v0.20-before-scenario-context/`.

| Location | Purpose |
|---|---|
| `dist/` | One static application, one state model and one calculation engine |
| `dist/locales/en.json` | Offline English UI catalog, including dynamic chart and scenario text |
| `dist/locales/locale.mjs` | Presentation-only translation and locale selection |
| `dist/locales/locale.css` | Language switch and long-English-label layout adjustments |
| `dist/data/*.json` | Unmodified canonical demo evidence and numeric data |
| `dist/data/en/documents.json` | English excerpts used by the evidence dialogs |
| `dist/data/en/*evidence.json`, `ai-input-*.json` | Translated business copies, with original and translation metadata |
| `docs/en/` | Human-readable English walkthrough, AI architecture and methodology |
| `docs/en/evidence/` | Ten complete translations of the existing selected demo excerpts |
| `docs/localization/` | Source-text inventory, reviewed translations, additions and provenance manifest |
| `exports/english-v0.26/` | Standalone English evidence and explanatory materials |
| `dist/downloads/ValueRange-English-Materials-v0.25.zip` | Downloadable copy of that English materials pack |

Chinese remains the canonical source for existing evidence. English filenames are readable aliases, not renamed production sources. The manifest keeps the original source names and hashes alongside English aliases and translation hashes.

## Language behavior

`?lang=en` and `?lang=zh` explicitly select a language. For this public release, a URL without a language parameter opens in English, even when an older browser preference was Chinese. In-page language changes update the URL. The URL's page hash is retained. The English / Chinese control updates presentation without recomputing financial inputs or replacing the separate candidate preview. Evidence readers select the matching translated document; Vault and Agent previews retain their local configuration.

The new lifecycle view also contains paired Chinese/English strings selected by the same locale setting. The catalog maps original message templates to reviewed English text. Number strings are substituted without reformatting or recalculation. IDs, data attributes, chart coordinates, links and machine statuses remain unchanged. Unknown messages retain their source text so missing coverage is visible during review rather than silently omitted.

English evidence is exported from local Markdown with its own SHA-256. Original file/excerpt and AI input/output hashes continue to identify the original records. The application checks excerpt-version identity before using the bundle; a changed source excerpt requires a translation refresh. UI copies describe translation as presentation, not a new AI or research run.

## Updating translations

From the demo root:

```text
python -X utf8 scripts/build_locales.py
python -X utf8 scripts/build_english_evidence.py
node scripts/collect_locale_ui.mjs
python -X utf8 scripts/extract_locale_ui.py --check
node scripts/check_flow_copy.mjs
python -X utf8 scripts/check_flow_copy.py
node --test tests/*.test.mjs
python -X utf8 scripts/package_english_materials.py
```

The original ordered `ui-source.json` inventory is frozen because reviewed TSV rows refer to its indices. Do not overwrite it when checking changes. Use `--check` to generate `ui-missing.json`; add new source templates and translations to `ui-extra.json`, then rebuild. Catalog compilation validates numbered placeholders.

For a changed source document, review and translate the changed content before re-exporting. Preserve source dates and calculations. Update translation dates/version metadata deliberately; rebuilding a bundle alone is not a research refresh.

## Review scope

This release preserves the v0.19 lifecycle and all financial outputs. It explains same-time comparison and separates measured asset/fee differences from hypotheses to review. The path selector now preserves the chosen target and duration. The instantaneous annualized fee equivalent appears only in the explanation drawer. The main case uses the dated $92.02 close; archived analytical defaults retain $88.53. Tests cover equal-capital initialization, P&L reconciliation, numeric placeholder integrity, original/translation hashes, financial table values and language-independent results. Guides describe the current path presets and year-four review; original business evidence is retained unchanged.

Coverage includes the guided strategy pages, live evidence, AI & research, the future landing page and its Vault/Agent previews, plus document readers and detailed workflow/AI views. English tables and long valuation diagrams retain horizontal scrolling inside their own containers.

This release is local. No public deployment, GitHub publication, new model generation, wallet operation or production workflow was performed for localization.

The header Reset demo button restores all simulation inputs, review drafts, observation cursors and Vault/Agent preview state, while preserving language and real evidence. The adjacent information button lists the fixed starting configuration.
