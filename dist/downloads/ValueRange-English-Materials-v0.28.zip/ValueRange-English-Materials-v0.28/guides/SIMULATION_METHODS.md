# Simulation and data methodology

Version 0.25 · 2026-09-18

The simulation explains conditional mechanisms over constructed one- to five-year paths. It is not a historical CIRCLE backtest or a forecast. Real monitoring, historical research, archived AI candidates and hypothetical outcomes are labeled separately.

The default demonstration uses a five-year repeated-cycle path ending at $85, viewed at the end of year five, with a company review at the end of year four. These are presentation defaults, not predictions. The five selectable horizons are 1, 2, 3, 4 and 5 years. A one-year case reviews at month six, mapped to day 183 on the whole-day clock. Longer cases review at a selected year-end before the horizon. Duration changes retain a valid review date or move it into the valid range. Path knots scale to the selected duration; fees use actual elapsed days, with annual reinvestment still checked only every 365 days. Price cycles remain distributed across the full horizon when the review year changes.

## Duration, target and price-path controls

The number field, five valuation cards and price slider share one ending-target input. Duration appears beside the target; the path template is chosen below. Changing a path retains the chosen target, horizon and fee assumptions, and resets observation to the end. The final segment reaches the chosen target, even if that implies a rebound after sustained pressure. Selecting Bear, Base or Bull uses that interval's midpoint. Extreme discount uses half the lower boundary; extreme premium uses 1.25 times the upper boundary. Targets are rounded to whole dollars and limited to the slider's $1-$400 range. Under the original valuation they are $6, $24, $62, $133 and $222; selecting a revised valuation immediately updates these illustrative targets. They are interaction presets, not forecasts.

Dragging the slider highlights the containing zone without snapping to a card's preset. All three price controls recalculate the same portfolio model and retain the path, horizon, observation time, fee rates and reinvestment choice. The plan's reference-price cards remain informational.

## Capital and inventory

The normalized opening portfolio is $10,000 at the August 25, 2026 CRCL close of $92.02 per share: Core 38.9545%, Active 20%, direct shares 37.2095%, stable-value reserve 3.836%. This reinitializes historical ranges and capital weights at a later dated close, not an account's transaction-by-transaction history or a daily target rebalance. See [the case reference](DEMO_REFERENCE.md) for the price source and path defaults. Original historical evidence retains its $88.53 reference.

For range [a,b], price p and liquidity L, let s = sqrt(clamp(p,a,b)):

```text
stock = L × (1/s − 1/sqrt(b))
cash  = L × (s − sqrt(a))
```

## Preset LP lifecycle

Version 0.19 adds a full execution lifecycle to the simulation. Historical opening ranges remain unchanged; the second exit and subsequent cycles are explicit demo rules, not a new AI run or verified live execution. The strategy is path-dependent: the same price may have different holdings after different prior actions.

| Trigger | Action | Funding |
|---|---|---|
| Initial deployment | Core [58,172.95], Active [90,115] | Historical weights, rebuilt at the dated demo price |
| Active reaches 115 | Close stage 1 and retain cash | Closing transfers the existing LP assets to the wallet |
| Recovery/rise to 130 after stage 1 | Open Active stage 2 [130,160] | Remaining eligible wallet shares only; realized cash is untouched |
| Stage 2 reaches 160 | Close it into wallet cash | No automatic repurchase in the old range |
| Broad Core reaches its upper boundary | Close into wallet cash | No new position at the high |
| Downward crossing of 75 | Withdraw old LPs; open Core accumulation [58,75] | Keep existing shares; use wallet cash above the initial reserve |
| Core accumulation reaches 58 | Close into shares and wait | All closed assets move to the wallet; no LP fees while closed |
| Recovery to 75 | Restart Core [75,172.95] | 60% of eligible wallet shares; no cash is exchanged to force a deployment |
| Recovery to 90 | Open Active stage 1 [90,115] | Half of the remaining eligible shares; retain the rest for stage 2 |

Active has an exit-only mandate. Core performs accumulation. A fixed tail of shares equivalent to 20% of starting capital is excluded from ordinary redeployments, and the initial $383.60 cash reserve is retained. These are demo policy constraints, not daily target weights or a promise of capital protection. Ordinary LP redeployments use existing asset quantities without a swap. If the available mix cannot fund a range, deployment is limited by the scarce asset and the rest stays in the wallet.

Disabling repeated deployment prevents new cycle positions, while existing LPs still close at their boundaries. Fundamental revisions replace this original cycle with the selected revised policy. They may override its tail and reserve constraints through an explicitly recorded rebalance.

Inside an LP range conversion remains two-way. For example, accumulation can reverse toward cash if price recovers before 58. Removing liquidity stops later reverse conversion in that old range; it does not erase past underperformance versus holding. The 58-to-75 gap separates accumulation completion from restarting. The engine processes only observed boundary crossings, without knowledge of future peaks or troughs. No rule claims to locate exact market bottoms or tops.

## Synchronized observation and holdings

A share-price panel and a portfolio-value panel share one observation time. The price panel shows the actual simulated price and valuation at that time; before a company review it uses the old valuation, and after the review it uses the revised valuation. The ending-price card remains a separate path input. Moving the time cursor inspects a point on the already-defined path; it does not itself trigger a rebalance.

The buy-and-hold line is a dollar portfolio value, not a share price. With no dividends or flows, it equals $10,000 times current price divided by opening price. Its percentage move follows the share-price percentage move, but their units differ.

The main exposure bar uses total NAV: all stock, including stock inside LPs, versus all cash, including LP cash and retained fees. The detailed table splits these assets into Core, Active, wallet and fee cash. Closed LPs have zero assets. A higher market-value weight is not proof that shares were bought; quantities and the before/after action ledger make that distinction visible.

## Fee rates and accounting

Daily simulation steps are split at every relevant range boundary. Each in-range subinterval earns:

```text
fee = LP principal valued at the subinterval midpoint × segment APR × elapsed years
```

Broad Core, Active distribution and Core accumulation use separate segment APRs and statistics. Broad Core and accumulation share the Core fee ledger; Active has its own ledger. Out-of-range capital, closed LPs, direct shares and waiting cash earn no LP fees. A year is 365 days. There is no leverage, external capital, cash interest, gas, slippage or opening/closing cost in the model.

The fixed calibration sample runs from 2026-08-24 13:48:34 to 2026-09-16 12:33:55 +08:00: 24 snapshots across 22.9482 days. It verifies position continuity, nondecreasing fee-token quantities, no recorded claims/rebalances in the window, and separate principal/fee fields. New token quantities are valued at each interval's ending price. Principal is time-integrated using endpoint averages and actual elapsed time. Repricing of old fees is excluded from new fee earnings.

| Segment | Observed new fees | Calendar-time observed APR | Simulation default |
|---|---:|---:|---:|
| Core | $223.21 | 28.0% | 14.0% |
| Active distribution | $313.10 | 74.6% | 37.3% |
| Core accumulation | No matching live sample | Not available | 14.0%, demo assumption |

Observed annualization = new fees / time-integrated principal × 365. The full window earned $536.31, with combined LP annualization 44.10%. Using average total NAV gives a portfolio fee annualization of 25.45%. Window fees equal 1.6742% of opening portfolio capital, not net ROI.

Observed denominators include out-of-range waiting. Intraday active-capital data is unavailable. Defaults use roughly a 50% haircut, then accrue only on future simulated in-range capital. This is a cautious assumption, not a statistical confidence interval or a historical revenue fit. Accumulation and newly migrated ranges are not volume-calibrated. Editable APRs range from 0.1% to 120%.

Presets, in Core / distribution / accumulation order: cautious 14 / 37.3 / 14; observed 28 / 74.6 / 14; low-fee 7 / 18.7 / 7. The short 26-hour 40.9% estimate is no longer the default. Latest live observations may differ from the fixed calibration sample and are labeled separately.

## LP APR is not portfolio ROI

- Average fee-earning capital = in-range principal-time integral / in-range time, including reinvestment.
- Current annualized portfolio fee contribution = sum of current eligible LP capital × its APR, divided by current NAV. Initially, Core's 38.9545% weight at 14% contributes about 5.45% per year; Active starts inside [90,115], so its 20% weight at 37.3% adds 7.46 percentage points, for about 12.91% combined. The archived $88.53 analytical baseline instead starts Active below range, contributing zero. This annualizes the current state, not the coming year.
- Cumulative fees / initial capital includes all simulated fee earnings, including fees after reinvestment; it is not net return.
- Cumulative ROI = NAV / $10,000 − 1, including price changes, management and fees. After all LPs close, new fee contribution is zero while existing fees remain in assets.

## Annual reinvestment

Each role tracks cumulative fees earned, fee cash not yet reinvested and cumulative reinvestment. Fees never move between Core and Active accounts. Each full 365 days, the engine first processes accrual, lifecycle events, fundamental changes and any stabilization rebuild, then checks reinvestment.

If the corresponding LP is open and price lies strictly inside its range, all that role's available fee cash is converted into the required share/cash mix and added as liquidity. Otherwise it stays in cash until the next annual check. Reinvestment never reopens a closed LP. Added liquidity earns only in subsequent intervals.

Total assets are unchanged at the reinvestment instant. A reinvestment at the final observation point cannot create extra ending profit.

```text
Cumulative fees earned = cumulative reinvested + remaining fee cash
NAV = current position principal + remaining fee cash
```

Reinvested fees and their later price changes are already in position value. Annual reinvestment is a demo management rule, not a Raydium automatic-reinvestment feature. This page does not claim, swap or add liquidity. Reinvestment can underperform retaining fee cash if prices subsequently fall.

## P&L and benchmarks

Four components sum to NAV − $10,000:

1. Price P&L from holding the opening share/cash mix.
2. The principal difference between a never-closed static LP allocation and that held mix, used as an impermanent-loss reference.
3. Managed principal − static LP principal − cumulative reinvested fees: cycle, range and reinvestment P&L. Deducting transferred fees avoids double counting while retaining their subsequent gains/losses. This is not entirely realized cash profit.
4. Cumulative simulated fees.

A fixed LP does not generate extra cycle profit merely because price makes a round trip. Additional path effects here come from closure, cash waiting and redeployment. Do not add IL or cycle components again to total P&L.

Buy-and-hold shares starts with the same capital and the same $92.02 opening price, then holds to the end. The fixed-valuation LP strategy keeps the original valuation and follows the preset lifecycle, which can close and redeploy different LP ranges. The dynamic strategy adjusts at the chosen review. All use the same market path. The $10,000 starting-capital line is constant and earns no interest. The never-closed static LP attribution reference is distinct from the fixed-valuation strategy.

## Comparison timeline and decision attribution

The comparison page opens at the end of the selected horizon. Its independent observation slider can inspect the start, the review point and later periods without changing the price path, policy or simulation-page cursor. Changing a valuation selection or review date preserves both observation cursors; language switching also preserves the current observation. The gray chart cursor moves with the slider while the purple review-date line remains fixed.

All three portfolio values, the current share price, ROI, cumulative fees and the decision difference use the same selected daily point. Full attribution and trade records also stop at that observation time. Before review both strategy paths are identical. Rebalancing conserves asset value at execution; subsequent market changes and fees create the difference over time.

```text
Total asset difference = revised NAV - original-valuation NAV
Fee income difference = revised cumulative fees - original cumulative fees
Holdings and redeployment difference = total asset difference - fee income difference
```

The last two components sum to the total asset difference. For presentation, total and fee differences are rounded to cents and the holdings residual absorbs cent rounding so the displayed equation also reconciles; calculations retain full precision. The holdings component includes stock/cash exposure, LP range management and price changes on reinvested fees; it is not all realized trading profit or an isolated measurement of AI's contribution. Fee income is already included in each NAV and must not be added again.

Example: five years, volatile-growth path, ending price $158, improvement reviewed at year four, default segment APRs and annual reinvestment. Revised ending assets are $27,891.66 versus $23,349.53 under unchanged valuation. The $4,542.13 advantage comprises $4,684.39 from holdings and redeployment and -$142.26 from fee income. The negative fee component means fewer fees were earned, despite the larger total asset value. This presentation revision leaves all underlying simulation values unchanged.

## Shared review controls and independent market assumptions (v0.22)

Review and Compare directly edit one shared simulation. Selecting a valuation scenario or review year immediately updates the valuation bands, portfolio calculation and comparison, without an Apply step. Review fee settings and explicit market examples also update the shared state. The Compare results button only navigates; it does not apply a second decision. The Review panel shows holdings at the review date while Run it and Compare retain their own observation cursors. The initial Plan remains the dated historical template. Compare also allows direct changes to the market path and ending price. Changing the thesis does not force the price to agree with valuation. Market price outside a valuation band does not prove an AI or Skill error.

Three optional examples pair a stated thesis with an illustrative market move: growth materializes (valuation up), persistent pressure (valuation down), and thesis/market divergence (valuation down followed by a rally). Loading one is an explicit action, not an automatic consequence of selecting a thesis. They are not optimized against portfolio returns and do not guarantee outperformance.

Loading an example preserves every price through the selected review day, inserts the interpolated review price as an anchor, then replaces only the later segment. All comparator portfolios use that identical complete path. Prices in the later segment are linear between four constructed knots, with a pullback/rebound along the way. The divergence example first weakens to the lesser of 65% of the review price and the old accumulation-band midpoint, then visits 80%, 110% and 100% of its ending price (clamped to $1–$400). This tests recovery and different re-entry decisions even when both portfolios start the review in cash. The ending-price control changes the final knot, not the frozen prefix.

Example endpoints are defined from valuation bands and the anchor price, then rounded and clamped to $1–$400: growth uses the greater of 1.35 times the anchor and the midpoint of the revised Bull band; pressure uses the lesser of 0.6 times the anchor and the revised Base midpoint; divergence uses the greater of 1.5 times the anchor and the original Bull midpoint. The endpoint appears on each example button before loading. Fees, horizon and existing execution assumptions are preserved.

Changing the review date after loading an example moves only the decision, leaving the market path fixed. Reload the example to rebuild its post-review segment around the new date. Choosing a named whole-horizon path or a different horizon explicitly replaces the example path. This distinction keeps changes in decision timing separate from changes in market history.

Interpretation reads only the selected observation prefix: price at review, subsequent low/high, price change, NAV and fee differences. Before review no later market performance is described as observed. The outcome block separates total P&L versus initial capital from the difference versus the original-valuation strategy and buy-and-hold.

For example, with five-year repeated swings, a pressure review at year three and an ending price of $150, revised assets are $24,142.88 versus $62,592.15 for the original valuation strategy. The $38,449.27 relative shortfall is not a loss of that amount from initial capital: the revised plan itself is up $14,142.88. After reducing exposure it misses subsequent swings, participation and fees. This is a constructed sensitivity case, not a diagnosis of the real company or proof that its research was wrong.

The header Reset demo restores the same configuration as a fresh walkthrough: $10,000 capital; $92.02 opening price; five years; repeated swings; $85 ending price; unchanged valuation; year-four review; 14% Core, 37.3% Active and 14% Core accumulation APR; annual reinvestment and repeated cycles enabled; recovery disabled; observation at the end. It also clears review drafts, comparison cursors, open evidence readers and product previews, then returns to the overview. Language preference and archived data are preserved.

## Fundamental revisions

Each valuation boundary is independently recalculated from average USDC, reserve yield, recurring Other Revenue, RLDC margin, OpEx, EV/EBITDA, net cash and diluted shares. Band width is price span, not probability.

| Scenario | Hypothetical factor changes | Approximate L0/L1/L2/L3 | Principal target at review |
|---|---|---|---|
| Material improvement | Average USDC +50%; RLDC margin +4 percentage points; recurring Other Revenue +40%; multiple unchanged | 33.39 / 79.72 / 174.02 / 328.13 | 25% Core, 0% Active, 70% shares, 5% cash |
| Material pressure | Average USDC -10%; yield -0.10 percentage points; RLDC margin -0.5 percentage points; multiple -45% | 6.35 / 17.39 / 41.90 / 83.86 | Exit both LPs; at most 10% shares, at least 90% cash |
| Broadly stable | No change | 11.32 / 35.81 / 88.71 / 177.86 | Continue existing ranges and lifecycle without forcing weights back |

Improvement closes old Active and increases direct growth exposure. The new Core uses the archived candidate's revised L1–L3 range. Core still sells shares on an increase and does not eliminate impermanent loss.

Pressure stops accumulation under old valuation. The archived candidate provides a 10% share target; the v0.19 execution policy treats it as an upper limit. If current shares already represent less than 10% of principal, keep that smaller quantity rather than buying into deteriorating fundamentals. Retained fee cash is separate from the principal denominator. An optional assumption supplies a verified stabilization signal one year later. Only once that review time has arrived and price is inside revised L1–L2 does the model rebuild once at 20% Core, 10% shares and 70% cash. Active stays paused. Without both conditions, no rebuild occurs. The assumed signal does not guarantee a subsequent rebound.

Targets are given demo constraints. AI supplies archived ranges and migration reasoning, not optimized weights. Rebalances use current price and existing principal with zero friction; uninvested fee cash remains separate. Reinvested fees have already become principal. Later market changes naturally alter weights.

Review can occur at the end of year 1 through N−1. The 2027E workbook is a research baseline; revised factors apply at the event and remain through the horizon. This is not a full annual financial forecast. Ending prices can range from $1 to $400. Values outside L0/L3 are extreme discounts/premiums relative to this model, not automatic trade signals.

## Actual evidence limits

The latest official snapshot is 2026-09-18 12:09:17 +08:00, with NAV $31,446.71 and unclaimed fees $682.26 already included. Since formal monitoring began, PNL is +$934.06; excess is $255.09 versus pure CRCLx and $326.44 versus the initial frozen mix. The strategy leads the non-interest-bearing USDC benchmark by $934.06.

Original and pool-price observations are not synchronous. Marking-method changes, missing full-cost and external-flow evidence, and limited market-cycle coverage constrain interpretation. The unrelated approximately $500 of fees from another wallet is excluded. See the full translated PNL excerpt for exact windows and all benchmarks.

## Full-period live fee history (v0.22)

The main live evidence page now uses the same observation window as its NAV and benchmark comparison: June 9, 2026 20:19:37 to September 18, 2026 12:09:17, UTC+8. The production CIRCLE LP NAV monitoring workbook is read only and each relevant value is cross-checked against its CSV export. There are 102 snapshots, including 49 observations with no LPs. Blank fee cells are treated as zero.

The workbook fields contain unclaimed balances and claimed-fee increments. Summing daily unclaimed balances would count the same fees repeatedly. Instead, the displayed **cumulative marked fee value** is:

```text
Recorded claims during the window + ending unclaimed balance - opening unclaimed balance
```

| Component | Core LP | Active LP | Total |
|---|---:|---:|---:|
| Recorded claims | $234.81 | $21.14 | $255.95 |
| Ending unclaimed balance | $383.95 | $298.31 | $682.26 |
| Less opening unclaimed balance | $0.95 | $0.00 | $0.95 |
| Cumulative marked fee value | $617.81 | $319.45 | $937.26 |

Calculation retains full precision and rounds only for display. The period starts with approximately $0.95 already unclaimed, so it is deducted from fees attributed to this window. Historical claims were confirmed by the owner on September 18 and reconcile to the workbook. Original ledger statuses are preserved in the source and provenance record; the demo does not show them as unresolved. Other-wallet fees are excluded.

This rollforward includes repricing of unclaimed fee tokens. It is not a pure quantity-accrual measure, so its value can fall and it cannot directly replace the separately calibrated simulation APRs. During stock-only periods the previously recorded claims carry forward; fees are neither erased nor counted again. The $682.26 ending unclaimed balance is already in NAV and in this rollforward, so it must not be added again. The $255.09 excess-versus-shares metric is a total-asset comparison, not fee income.

The deterministic export is in `scripts/export_fee_history.py`; the public demo copy is `dist/data/history.json` under `feeHistory`. Source workbook, CSV and ledger SHA-256 hashes and the reconciliation formula accompany that copy. Production files are unchanged.

## Plan walkthrough and compact evidence (v0.23)

The Plan page now follows valuation context → AI range proposal → starting allocation. The recorded $92.02 close sits inside both initial LP ranges, making inventory changes and fees visible from the start. The date remains on the page; price-source provenance remains in the case-reference guide. Two direct questions open the valuation calculation and the archived AI allocation rationale. Historical inputs and numerical assumptions are unchanged.

Live evidence shows its cumulative marked fee value once in the headline metrics. The time-series fee chart has been removed from the main page. Fee totals by role, claims, unclaimed balances and the unchanged rollforward formula are available in a collapsed calculation section. This is a presentation change, not a revision to recorded fees or the NAV comparison.


## Understand the decision and review it (v0.24)

The Review page displays currently fee-eligible LPs instead of an annualized dollar amount on the primary surface. The explanation drawer retains the snapshot's in-range capital × APR equivalent. This is neither immediate profit nor a one-year forecast. Rebalancing conserves assets; Compare subsequently accrues fees over the same simulated price path and combines them with holdings and range results.

The comparison first shows the measured asset difference, split into holdings/range decisions and extra or forgone fees. It then distinguishes relative underperformance from the plan's own profit or loss. Possible causes to investigate include stale business assumptions, temporary divergence between price and company value, and unsuitable trading/re-entry rules. These are review questions, not proof that the market or AI is wrong. Explanations do not use prices after the selected observation time.

Live evidence introduces the strategy as an allocation approach for a company already selected: retain share exposure, collect LP fees and trade in stages. The objective is to outperform holding that same stock. LP selling can sacrifice upside; fees and staged trades seek to offset the gap but need validation across different markets. The explanation is not a new numerical attribution of the live portfolio and makes no claim that more capital, iteration or elapsed time necessarily increases returns or win rate.

## Fresh visits and a single path selector · v0.26

Each new document load or refresh starts at the overview with the default five-year, $85 repeated-swing case, even when the copied URL contains a step fragment. Restoring a cached document also starts a new case. The language query is retained; moving between steps or switching language inside the current document preserves the scenario. This demo intentionally favors a reproducible first visit over resuming a previous experiment.

Run it and Compare share all seven path templates and labels. The Run page uses one selector and a preview generated from the same price knots as the calculation engine. Duration and target remain independent. Loaded review examples have their own selected label until replaced. The settings drawer no longer contains a second price-path selector.

“Buy back and reopen LPs when conditions are met” controls repeated trading with available portfolio funds. Sale proceeds may buy shares at a pullback trigger and fund LPs again on recovery. When off, existing LPs finish at their exit conditions without reopening under the original rules. “Reinvest fees annually” separately controls earned fees: add them to eligible in-range LPs at year-end, or retain them as cash. A valuation revision follows its new allocation policy.

The next step is “Next: adjust valuation & positions.” It changes the valuation assumptions and allocation at the review date, while the market-price assumption remains independent.

 Simulation and data methodology

Version 0.25 · 2026-09-18

The simulation explains conditional mechanisms over constructed one- to five-year paths. It is not a historical CIRCLE backtest or a forecast. Real monitoring, historical research, archived AI candidates and hypothetical outcomes are labeled separately.

The default demonstration uses a five-year repeated-cycle path ending at $85, viewed at the end of year five, with a company review at the end of year four. These are presentation defaults, not predictions. The five selectable horizons are 1, 2, 3, 4 and 5 years. A one-year case reviews at month six, mapped to day 183 on the whole-day clock. Longer cases review at a selected year-end before the horizon. Duration changes retain a valid review date or move it into the valid range. Path knots scale to the selected duration; fees use actual elapsed days, with annual reinvestment still checked only every 365 days. Price cycles remain distributed across the full horizon when the review year changes.

## Duration, target and price-path controls

The number field, five valuation cards and price slider share one ending-target input. Duration appears beside the target; the path template is chosen below. Changing a path retains the chosen target, horizon and fee assumptions, and resets observation to the end. The final segment reaches the chosen target, even if that implies a rebound after sustained pressure. Selecting Bear, Base or Bull uses that interval's midpoint. Extreme discount uses half the lower boundary; extreme premium uses 1.25 times the upper boundary. Targets are rounded to whole dollars and limited to the slider's $1-$400 range. Under the original valuation they are $6, $24, $62, $133 and $222; selecting a revised valuation immediately updates these illustrative targets. They are interaction presets, not forecasts.

Dragging the slider highlights the containing zone without snapping to a card's preset. All three price controls recalculate the same portfolio model and retain the path, horizon, observation time, fee rates and reinvestment choice. The plan's reference-price cards remain informational.

## Capital and inventory

The normalized opening portfolio is $10,000 at the August 25, 2026 CRCL close of $92.02 per share: Core 38.9545%, Active 20%, direct shares 37.2095%, stable-value reserve 3.836%. This reinitializes historical ranges and capital weights at a later dated close, not an account's transaction-by-transaction history or a daily target rebalance. See [the case reference](DEMO_REFERENCE.md) for the price source and path defaults. Original historical evidence retains its $88.53 reference.

For range [a,b], price p and liquidity L, let s = sqrt(clamp(p,a,b)):

```text
stock = L × (1/s − 1/sqrt(b))
cash  = L × (s − sqrt(a))
```

## Preset LP lifecycle

Version 0.19 adds a full execution lifecycle to the simulation. Historical opening ranges remain unchanged; the second exit and subsequent cycles are explicit demo rules, not a new AI run or verified live execution. The strategy is path-dependent: the same price may have different holdings after different prior actions.

| Trigger | Action | Funding |
|---|---|---|
| Initial deployment | Core [58,172.95], Active [90,115] | Historical weights, rebuilt at the dated demo price |
| Active reaches 115 | Close stage 1 and retain cash | Closing transfers the existing LP assets to the wallet |
| Recovery/rise to 130 after stage 1 | Open Active stage 2 [130,160] | Remaining eligible wallet shares only; realized cash is untouched |
| Stage 2 reaches 160 | Close it into wallet cash | No automatic repurchase in the old range |
| Broad Core reaches its upper boundary | Close into wallet cash | No new position at the high |
| Downward crossing of 75 | Withdraw old LPs; open Core accumulation [58,75] | Keep existing shares; use wallet cash above the initial reserve |
| Core accumulation reaches 58 | Close into shares and wait | All closed assets move to the wallet; no LP fees while closed |
| Recovery to 75 | Restart Core [75,172.95] | 60% of eligible wallet shares; no cash is exchanged to force a deployment |
| Recovery to 90 | Open Active stage 1 [90,115] | Half of the remaining eligible shares; retain the rest for stage 2 |

Active has an exit-only mandate. Core performs accumulation. A fixed tail of shares equivalent to 20% of starting capital is excluded from ordinary redeployments, and the initial $383.60 cash reserve is retained. These are demo policy constraints, not daily target weights or a promise of capital protection. Ordinary LP redeployments use existing asset quantities without a swap. If the available mix cannot fund a range, deployment is limited by the scarce asset and the rest stays in the wallet.

Disabling repeated deployment prevents new cycle positions, while existing LPs still close at their boundaries. Fundamental revisions replace this original cycle with the selected revised policy. They may override its tail and reserve constraints through an explicitly recorded rebalance.

Inside an LP range conversion remains two-way. For example, accumulation can reverse toward cash if price recovers before 58. Removing liquidity stops later reverse conversion in that old range; it does not erase past underperformance versus holding. The 58-to-75 gap separates accumulation completion from restarting. The engine processes only observed boundary crossings, without knowledge of future peaks or troughs. No rule claims to locate exact market bottoms or tops.

## Synchronized observation and holdings

A share-price panel and a portfolio-value panel share one observation time. The price panel shows the actual simulated price and valuation at that time; before a company review it uses the old valuation, and after the review it uses the revised valuation. The ending-price card remains a separate path input. Moving the time cursor inspects a point on the already-defined path; it does not itself trigger a rebalance.

The buy-and-hold line is a dollar portfolio value, not a share price. With no dividends or flows, it equals $10,000 times current price divided by opening price. Its percentage move follows the share-price percentage move, but their units differ.

The main exposure bar uses total NAV: all stock, including stock inside LPs, versus all cash, including LP cash and retained fees. The detailed table splits these assets into Core, Active, wallet and fee cash. Closed LPs have zero assets. A higher market-value weight is not proof that shares were bought; quantities and the before/after action ledger make that distinction visible.

## Fee rates and accounting

Daily simulation steps are split at every relevant range boundary. Each in-range subinterval earns:

```text
fee = LP principal valued at the subinterval midpoint × segment APR × elapsed years
```

Broad Core, Active distribution and Core accumulation use separate segment APRs and statistics. Broad Core and accumulation share the Core fee ledger; Active has its own ledger. Out-of-range capital, closed LPs, direct shares and waiting cash earn no LP fees. A year is 365 days. There is no leverage, external capital, cash interest, gas, slippage or opening/closing cost in the model.

The fixed calibration sample runs from 2026-08-24 13:48:34 to 2026-09-16 12:33:55 +08:00: 24 snapshots across 22.9482 days. It verifies position continuity, nondecreasing fee-token quantities, no recorded claims/rebalances in the window, and separate principal/fee fields. New token quantities are valued at each interval's ending price. Principal is time-integrated using endpoint averages and actual elapsed time. Repricing of old fees is excluded from new fee earnings.

| Segment | Observed new fees | Calendar-time observed APR | Simulation default |
|---|---:|---:|---:|
| Core | $223.21 | 28.0% | 14.0% |
| Active distribution | $313.10 | 74.6% | 37.3% |
| Core accumulation | No matching live sample | Not available | 14.0%, demo assumption |

Observed annualization = new fees / time-integrated principal × 365. The full window earned $536.31, with combined LP annualization 44.10%. Using average total NAV gives a portfolio fee annualization of 25.45%. Window fees equal 1.6742% of opening portfolio capital, not net ROI.

Observed denominators include out-of-range waiting. Intraday active-capital data is unavailable. Defaults use roughly a 50% haircut, then accrue only on future simulated in-range capital. This is a cautious assumption, not a statistical confidence interval or a historical revenue fit. Accumulation and newly migrated ranges are not volume-calibrated. Editable APRs range from 0.1% to 120%.

Presets, in Core / distribution / accumulation order: cautious 14 / 37.3 / 14; observed 28 / 74.6 / 14; low-fee 7 / 18.7 / 7. The short 26-hour 40.9% estimate is no longer the default. Latest live observations may differ from the fixed calibration sample and are labeled separately.

## LP APR is not portfolio ROI

- Average fee-earning capital = in-range principal-time integral / in-range time, including reinvestment.
- Current annualized portfolio fee contribution = sum of current eligible LP capital × its APR, divided by current NAV. Initially, Core's 38.9545% weight at 14% contributes about 5.45% per year; Active starts inside [90,115], so its 20% weight at 37.3% adds 7.46 percentage points, for about 12.91% combined. The archived $88.53 analytical baseline instead starts Active below range, contributing zero. This annualizes the current state, not the coming year.
- Cumulative fees / initial capital includes all simulated fee earnings, including fees after reinvestment; it is not net return.
- Cumulative ROI = NAV / $10,000 − 1, including price changes, management and fees. After all LPs close, new fee contribution is zero while existing fees remain in assets.

## Annual reinvestment

Each role tracks cumulative fees earned, fee cash not yet reinvested and cumulative reinvestment. Fees never move between Core and Active accounts. Each full 365 days, the engine first processes accrual, lifecycle events, fundamental changes and any stabilization rebuild, then checks reinvestment.

If the corresponding LP is open and price lies strictly inside its range, all that role's available fee cash is converted into the required share/cash mix and added as liquidity. Otherwise it stays in cash until the next annual check. Reinvestment never reopens a closed LP. Added liquidity earns only in subsequent intervals.

Total assets are unchanged at the reinvestment instant. A reinvestment at the final observation point cannot create extra ending profit.

```text
Cumulative fees earned = cumulative reinvested + remaining fee cash
NAV = current position principal + remaining fee cash
```

Reinvested fees and their later price changes are already in position value. Annual reinvestment is a demo management rule, not a Raydium automatic-reinvestment feature. This page does not claim, swap or add liquidity. Reinvestment can underperform retaining fee cash if prices subsequently fall.

## P&L and benchmarks

Four components sum to NAV − $10,000:

1. Price P&L from holding the opening share/cash mix.
2. The principal difference between a never-closed static LP allocation and that held mix, used as an impermanent-loss reference.
3. Managed principal − static LP principal − cumulative reinvested fees: cycle, range and reinvestment P&L. Deducting transferred fees avoids double counting while retaining their subsequent gains/losses. This is not entirely realized cash profit.
4. Cumulative simulated fees.

A fixed LP does not generate extra cycle profit merely because price makes a round trip. Additional path effects here come from closure, cash waiting and redeployment. Do not add IL or cycle components again to total P&L.

Buy-and-hold shares starts with the same capital and the same $92.02 opening price, then holds to the end. The fixed-valuation LP strategy keeps the original valuation and follows the preset lifecycle, which can close and redeploy different LP ranges. The dynamic strategy adjusts at the chosen review. All use the same market path. The $10,000 starting-capital line is constant and earns no interest. The never-closed static LP attribution reference is distinct from the fixed-valuation strategy.

## Comparison timeline and decision attribution

The comparison page opens at the end of the selected horizon. Its independent observation slider can inspect the start, the review point and later periods without changing the price path, policy or simulation-page cursor. Changing a valuation selection or review date preserves both observation cursors; language switching also preserves the current observation. The gray chart cursor moves with the slider while the purple review-date line remains fixed.

All three portfolio values, the current share price, ROI, cumulative fees and the decision difference use the same selected daily point. Full attribution and trade records also stop at that observation time. Before review both strategy paths are identical. Rebalancing conserves asset value at execution; subsequent market changes and fees create the difference over time.

```text
Total asset difference = revised NAV - original-valuation NAV
Fee income difference = revised cumulative fees - original cumulative fees
Holdings and redeployment difference = total asset difference - fee income difference
```

The last two components sum to the total asset difference. For presentation, total and fee differences are rounded to cents and the holdings residual absorbs cent rounding so the displayed equation also reconciles; calculations retain full precision. The holdings component includes stock/cash exposure, LP range management and price changes on reinvested fees; it is not all realized trading profit or an isolated measurement of AI's contribution. Fee income is already included in each NAV and must not be added again.

Example: five years, volatile-growth path, ending price $158, improvement reviewed at year four, default segment APRs and annual reinvestment. Revised ending assets are $27,891.66 versus $23,349.53 under unchanged valuation. The $4,542.13 advantage comprises $4,684.39 from holdings and redeployment and -$142.26 from fee income. The negative fee component means fewer fees were earned, despite the larger total asset value. This presentation revision leaves all underlying simulation values unchanged.

## Shared review controls and independent market assumptions (v0.22)

Review and Compare directly edit one shared simulation. Selecting a valuation scenario or review year immediately updates the valuation bands, portfolio calculation and comparison, without an Apply step. Review fee settings and explicit market examples also update the shared state. The Compare results button only navigates; it does not apply a second decision. The Review panel shows holdings at the review date while Run it and Compare retain their own observation cursors. The initial Plan remains the dated historical template. Compare also allows direct changes to the market path and ending price. Changing the thesis does not force the price to agree with valuation. Market price outside a valuation band does not prove an AI or Skill error.

Three optional examples pair a stated thesis with an illustrative market move: growth materializes (valuation up), persistent pressure (valuation down), and thesis/market divergence (valuation down followed by a rally). Loading one is an explicit action, not an automatic consequence of selecting a thesis. They are not optimized against portfolio returns and do not guarantee outperformance.

Loading an example preserves every price through the selected review day, inserts the interpolated review price as an anchor, then replaces only the later segment. All comparator portfolios use that identical complete path. Prices in the later segment are linear between four constructed knots, with a pullback/rebound along the way. The divergence example first weakens to the lesser of 65% of the review price and the old accumulation-band midpoint, then visits 80%, 110% and 100% of its ending price (clamped to $1–$400). This tests recovery and different re-entry decisions even when both portfolios start the review in cash. The ending-price control changes the final knot, not the frozen prefix.

Example endpoints are defined from valuation bands and the anchor price, then rounded and clamped to $1–$400: growth uses the greater of 1.35 times the anchor and the midpoint of the revised Bull band; pressure uses the lesser of 0.6 times the anchor and the revised Base midpoint; divergence uses the greater of 1.5 times the anchor and the original Bull midpoint. The endpoint appears on each example button before loading. Fees, horizon and existing execution assumptions are preserved.

Changing the review date after loading an example moves only the decision, leaving the market path fixed. Reload the example to rebuild its post-review segment around the new date. Choosing a named whole-horizon path or a different horizon explicitly replaces the example path. This distinction keeps changes in decision timing separate from changes in market history.

Interpretation reads only the selected observation prefix: price at review, subsequent low/high, price change, NAV and fee differences. Before review no later market performance is described as observed. The outcome block separates total P&L versus initial capital from the difference versus the original-valuation strategy and buy-and-hold.

For example, with five-year repeated swings, a pressure review at year three and an ending price of $150, revised assets are $24,142.88 versus $62,592.15 for the original valuation strategy. The $38,449.27 relative shortfall is not a loss of that amount from initial capital: the revised plan itself is up $14,142.88. After reducing exposure it misses subsequent swings, participation and fees. This is a constructed sensitivity case, not a diagnosis of the real company or proof that its research was wrong.

The header Reset demo restores the same configuration as a fresh walkthrough: $10,000 capital; $92.02 opening price; five years; repeated swings; $85 ending price; unchanged valuation; year-four review; 14% Core, 37.3% Active and 14% Core accumulation APR; annual reinvestment and repeated cycles enabled; recovery disabled; observation at the end. It also clears review drafts, comparison cursors, open evidence readers and product previews, then returns to the overview. Language preference and archived data are preserved.

## Fundamental revisions

Each valuation boundary is independently recalculated from average USDC, reserve yield, recurring Other Revenue, RLDC margin, OpEx, EV/EBITDA, net cash and diluted shares. Band width is price span, not probability.

| Scenario | Hypothetical factor changes | Approximate L0/L1/L2/L3 | Principal target at review |
|---|---|---|---|
| Material improvement | Average USDC +50%; RLDC margin +4 percentage points; recurring Other Revenue +40%; multiple unchanged | 33.39 / 79.72 / 174.02 / 328.13 | 25% Core, 0% Active, 70% shares, 5% cash |
| Material pressure | Average USDC -10%; yield -0.10 percentage points; RLDC margin -0.5 percentage points; multiple -45% | 6.35 / 17.39 / 41.90 / 83.86 | Exit both LPs; at most 10% shares, at least 90% cash |
| Broadly stable | No change | 11.32 / 35.81 / 88.71 / 177.86 | Continue existing ranges and lifecycle without forcing weights back |

Improvement closes old Active and increases direct growth exposure. The new Core uses the archived candidate's revised L1–L3 range. Core still sells shares on an increase and does not eliminate impermanent loss.

Pressure stops accumulation under old valuation. The archived candidate provides a 10% share target; the v0.19 execution policy treats it as an upper limit. If current shares already represent less than 10% of principal, keep that smaller quantity rather than buying into deteriorating fundamentals. Retained fee cash is separate from the principal denominator. An optional assumption supplies a verified stabilization signal one year later. Only once that review time has arrived and price is inside revised L1–L2 does the model rebuild once at 20% Core, 10% shares and 70% cash. Active stays paused. Without both conditions, no rebuild occurs. The assumed signal does not guarantee a subsequent rebound.

Targets are given demo constraints. AI supplies archived ranges and migration reasoning, not optimized weights. Rebalances use current price and existing principal with zero friction; uninvested fee cash remains separate. Reinvested fees have already become principal. Later market changes naturally alter weights.

Review can occur at the end of year 1 through N−1. The 2027E workbook is a research baseline; revised factors apply at the event and remain through the horizon. This is not a full annual financial forecast. Ending prices can range from $1 to $400. Values outside L0/L3 are extreme discounts/premiums relative to this model, not automatic trade signals.

## Actual evidence limits

The latest official snapshot is 2026-09-18 12:09:17 +08:00, with NAV $31,446.71 and unclaimed fees $682.26 already included. Since formal monitoring began, PNL is +$934.06; excess is $255.09 versus pure CRCLx and $326.44 versus the initial frozen mix. The strategy leads the non-interest-bearing USDC benchmark by $934.06.

Original and pool-price observations are not synchronous. Marking-method changes, missing full-cost and external-flow evidence, and limited market-cycle coverage constrain interpretation. The unrelated approximately $500 of fees from another wallet is excluded. See the full translated PNL excerpt for exact windows and all benchmarks.

## Full-period live fee history (v0.22)

The main live evidence page now uses the same observation window as its NAV and benchmark comparison: June 9, 2026 20:19:37 to September 18, 2026 12:09:17, UTC+8. The production CIRCLE LP NAV monitoring workbook is read only and each relevant value is cross-checked against its CSV export. There are 102 snapshots, including 49 observations with no LPs. Blank fee cells are treated as zero.

The workbook fields contain unclaimed balances and claimed-fee increments. Summing daily unclaimed balances would count the same fees repeatedly. Instead, the displayed **cumulative marked fee value** is:

```text
Recorded claims during the window + ending unclaimed balance - opening unclaimed balance
```

| Component | Core LP | Active LP | Total |
|---|---:|---:|---:|
| Recorded claims | $234.81 | $21.14 | $255.95 |
| Ending unclaimed balance | $383.95 | $298.31 | $682.26 |
| Less opening unclaimed balance | $0.95 | $0.00 | $0.95 |
| Cumulative marked fee value | $617.81 | $319.45 | $937.26 |

Calculation retains full precision and rounds only for display. The period starts with approximately $0.95 already unclaimed, so it is deducted from fees attributed to this window. Historical claims were confirmed by the owner on September 18 and reconcile to the workbook. Original ledger statuses are preserved in the source and provenance record; the demo does not show them as unresolved. Other-wallet fees are excluded.

This rollforward includes repricing of unclaimed fee tokens. It is not a pure quantity-accrual measure, so its value can fall and it cannot directly replace the separately calibrated simulation APRs. During stock-only periods the previously recorded claims carry forward; fees are neither erased nor counted again. The $682.26 ending unclaimed balance is already in NAV and in this rollforward, so it must not be added again. The $255.09 excess-versus-shares metric is a total-asset comparison, not fee income.

The deterministic export is in `scripts/export_fee_history.py`; the public demo copy is `dist/data/history.json` under `feeHistory`. Source workbook, CSV and ledger SHA-256 hashes and the reconciliation formula accompany that copy. Production files are unchanged.

## Plan walkthrough and compact evidence (v0.23)

The Plan page now follows valuation context → AI range proposal → starting allocation. The recorded $92.02 close sits inside both initial LP ranges, making inventory changes and fees visible from the start. The date remains on the page; price-source provenance remains in the case-reference guide. Two direct questions open the valuation calculation and the archived AI allocation rationale. Historical inputs and numerical assumptions are unchanged.

Live evidence shows its cumulative marked fee value once in the headline metrics. The time-series fee chart has been removed from the main page. Fee totals by role, claims, unclaimed balances and the unchanged rollforward formula are available in a collapsed calculation section. This is a presentation change, not a revision to recorded fees or the NAV comparison.


## Understand the decision and review it (v0.24)

The Review page displays currently fee-eligible LPs instead of an annualized dollar amount on the primary surface. The explanation drawer retains the snapshot's in-range capital × APR equivalent. This is neither immediate profit nor a one-year forecast. Rebalancing conserves assets; Compare subsequently accrues fees over the same simulated price path and combines them with holdings and range results.

The comparison first shows the measured asset difference, split into holdings/range decisions and extra or forgone fees. It then distinguishes relative underperformance from the plan's own profit or loss. Possible causes to investigate include stale business assumptions, temporary divergence between price and company value, and unsuitable trading/re-entry rules. These are review questions, not proof that the market or AI is wrong. Explanations do not use prices after the selected observation time.

Live evidence introduces the strategy as an allocation approach for a company already selected: retain share exposure, collect LP fees and trade in stages. The objective is to outperform holding that same stock. LP selling can sacrifice upside; fees and staged trades seek to offset the gap but need validation across different markets. The explanation is not a new numerical attribution of the live portfolio and makes no claim that more capital, iteration or elapsed time necessarily increases returns or win rate.
