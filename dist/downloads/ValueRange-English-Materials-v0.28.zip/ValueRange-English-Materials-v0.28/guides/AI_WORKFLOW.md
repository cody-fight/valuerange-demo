# AI workflow and evidence

Version 0.16 · 2026-09-17

The product's core idea is to use company valuation as a foundation for on-chain inventory decisions. AI proposes constrained LP and holding plans; explicit mathematics computes their consequences. Ongoing research can prompt a review when the company's operating outlook changes.

## Responsibilities

| Layer | Responsibility | Review boundary |
|---|---|---|
| Research Skills | Define financial methods, source standards, company classification and valuation conventions | Private methodology is not distributed with this demo |
| AI | Connect evidence to operating factors; propose ranges, migration reasoning and exceptions under supplied constraints | A candidate is not an executed position |
| Deterministic code | Recalculate valuation nodes, CLMM inventory, fee accrual, NAV/PNL and equal-capital comparisons | AI explanations cannot overwrite calculated values |
| Harness | Order dependencies, record versions and run status, retain coverage degradation and evidence | A successful program run does not imply complete research coverage |
| Human approval and execution controls | Review intent, check deployable funds and restrictions, reconcile plans to on-chain facts | The demo does not sign or execute transactions |

Daily monitoring, a valuation rebuild and LP generation are distinct workflows. New information can trigger a review without changing valuation. An unchanged conclusion is a valid research result when evidence is insufficient.

## Evidence timeline

### Historical CIRCLE research and strategy

The financial workbook is frozen at 2026-08-22 and models normalized 2027E operations. Four ordered boundaries, L0–L3, form continuous bear/base/bull ranges: $11.32 / $35.81 / $88.71 / $177.86. They derive from business assumptions, not from the market price or technical indicators.

The 2026-08-24 historical AI proposal used the valuation anchor, technical information through August 21, existing inventory and holding objectives. It proposed retaining Core and opening a 20% inventory-funded Active distribution range at $90–115. Its strategy intent was subsequently approved by the user. The archived proposal remains separate from later monitoring and synthetic cases.

### Actual daily monitoring on September 17

The public business excerpt records ten scheduled nodes of `CIRCLE_DAILY_20260917-1243`, approximately 12:43–13:10 +08:00. Program modules completed, while the overall run retained degraded research coverage because key regulatory material was not fully retrieved.

The run kept valuation and strategy unchanged. It did not generate new LP ranges or execute a trade. NAV and PNL are observed at 12:43:53 +08:00; this is an archived snapshot, not a live browser refresh.

### Two actual model calls using hypothetical inputs

Archive: `demo-ai-20260917-v09`. Isolated generation began at 2026-09-17 14:25:53 +08:00. Improvement completed at 14:28:25 and pressure at 14:30:07. The requested and CLI-reported model was `gpt-5.6-luna` with xhigh reasoning. Service tier was not independently confirmed; run metadata is not an independent audit.

The calls reused the existing private AMM Skill and Harness invocation configuration. Inputs included synthetic holdings immediately before the year-two review, price nodes known up to that point, separately recalculated valuation boundaries and given holding objectives. Subsequent prices and returns were not supplied. Actual news, candles, ATR and RSI were not fabricated.

Allocation weights were specified demo constraints, not model-optimized portfolios. AI produced Core reference ranges, handling of old Active, migration reasons, funding checks and equity-beta trade-offs:

- Improvement: Core reference $79.72–328.13; target 25% Core, 0% Active, 70% direct shares, 5% cash.
- Pressure: Core reference about $17.39–83.86, initially inactive; target 0% Core, 0% Active, 10% shares, 90% cash.

Both candidates flag direct-rebalancing exceptions for review. The simulation implements targets as instantaneous frictionless rebalances. In v0.19, defensive shares are capped at 10% rather than purchased to meet that weight when existing exposure is already lower. This execution constraint does not change the archived model output. This does not demonstrate completion of production LP-first migration preflight or any on-chain execution. The optional stabilization rule—20% Core, 10% shares, 70% cash—is a pre-existing demo management rule, not an optimization produced by those calls.

Changing a browser control loads an archived candidate template and recalculates mathematics. It does not ask the model to judge the new inputs. The archive's original review price is $100, regardless of the visitor's current simulation.

## Demo execution layer

Local v0.19 adds preset Core/Active close, wait and restart rules, a second Active exit stage, and a stock/cash inventory ledger. These rules are deterministic demonstration policy, not additional outputs of the archived model calls. Active handles exits; Core handles accumulation. The preset tail-share quantity, cash reserve, trigger prices and restart proportions are disclosed in the interface and [simulation methodology](SIMULATION_METHODS.md). Existing AI input/output records and hashes remain unchanged.

## Continuous user journey

The overview introduces the product before taking the visitor through plan, simulation, company review and comparison. The default simulation starts at the dated August 25, 2026 CRCL close of $92.02, follows a five-year repeated-cycle path and ends at a hypothetical $85. The historical plan is a template: quantities are recalculated at the new opening price without changing the archived AI inputs. See [the case reference](DEMO_REFERENCE.md). It opens at the end of year five, with the company review set to the end of year four. Visitors can adjust duration from one to five years, the path, ending price, review time and fee assumptions. The one-year case reviews at month six (day 183); 2–5-year cases retain annual review dates. Path buttons retain the visitor’s chosen target and horizon; only the intervening path template changes. The number field, cards and slider share that target. The valuation colors follow the selected price and company scenario. Review choices update the shared simulation immediately; the comparison button only navigates. This changes the demo interaction, not the approval requirements of the archived production workflow.

Company Review receives the current market path and portfolio. Switching the business thesis changes valuation and allocation rules without silently replacing the market path. The Compare results button opens a comparison of the adjusted strategy, original LP plan and buy-and-hold shares on the same capital and price path. The time cursor reveals outcomes observed up to that point.

`reviewSnapshot` is sampled after that day's fee accrual and original lifecycle events, but before fundamental rebalancing and annual reinvestment. `revisionSnapshot` is after rebalancing and before reinvestment. Principal, NAV and cumulative fees are conserved across the adjustment. The day's final simulation point can include subsequent annual reinvestment.

The v0.20 comparison adds a time cursor and decomposes the total asset difference into fee income and holdings/redeployment at that same time. A negative fee difference does not imply a negative total decision result.

The review shows which LPs can earn fees at the rebalance snapshot. Its secondary explanation contains the instantaneous in-range capital × APR equivalent, explicitly not an immediate profit or annual forecast. Compare accumulates fees along the path using the same fee rules. The remaining holdings/range difference includes post-reinvestment gains or losses; it is not all attributable to AI.

The result page offers possible review questions about business assumptions, price/value divergence and execution rules. These are hypotheses, not diagnoses generated by a live model. They appear only after the review and use observed data. The described iteration loop is evidence refresh → valuation review → rule refinement → further testing; a favorable simulation alone does not validate the whole workflow.

The recorded AI calls above used a year-two review. Reusing those archived templates in the current year-four default does not create a new model run or imply a fresh AI assessment of that point. Scenario targets remain given demonstration constraints.

The future Vault and self-custodial Agent interfaces are separate product previews. Their local controls do not change the main simulation, connect a wallet or call a model. See [future product previews](FUTURE_PREVIEWS.md) for the planned research-to-execution loop and permission boundaries.

## Public evidence and private engineering

The demo exposes selected business inputs, outputs, constraints, source identities, hashes and monitoring statuses. It keeps complete Skills, internal prompts, model-call logs and private production orchestration outside the web directory.

English records in `dist/data/en/` and `docs/en/evidence/` are translations. Original run dates and input/output hashes continue to refer to the original records. Separate translation hashes identify the English artifact. Neither translation nor a changed simulation constitutes a new AI run.
