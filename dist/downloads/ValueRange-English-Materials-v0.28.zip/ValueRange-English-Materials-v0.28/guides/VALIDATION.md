# v0.27 · A read-only plan, from valuation to allocation

The Plan page separates the valuation model and closing-price position from AI-proposed LP ranges and capital weights. Its figures are read-only and use a shared linear dollar scale; simulation cards remain interactive. The valuation evidence link belongs to step 01, and AI range/weight reasoning belongs to step 02. Financial source data and simulation rules are unchanged.

# Local demo validation

## v0.26 · Fresh starts and unified path controls

September 18, 2026. All 90 Node tests pass. Path coverage now includes all seven templates, retained target and duration, unique selected options, loaded-example labeling and valid preview endpoints. The existing engine and evidence tests continue to pass.

The startup defaults and manual reset use the same state factory. New documents ignore copied step fragments and begin at the overview; browser-restored documents also reset. Ordinary in-page navigation and language switching retain state. Price-path options share one catalog between Run and Compare, and the preview draws the actual simulation knots.

The English audit covers 567 rendered states with no missing templates. Browser checks verified a copied result URL in a fresh window, defaults after refreshing an edited scenario, two independent switches, Run/Compare path synchronization, language preservation and a legible 390px layout without horizontal overflow. The public site remains v0.25 until the next deployment.

The cycle setting and annual fee-reinvestment setting keep their existing financial behavior; their meanings are now explained separately. The duplicated path selector was removed from the settings drawer. Archived evidence, APR assumptions and calculation formulas were not changed.

## Earlier v0.25 validation

Local v0.25 · September 18, 2026

## Five selectable horizons

The complete simulation supports 1, 2, 3, 4 and 5 years. The default remains five years. A one-year case reviews at month six, represented by day 183 on the whole-day clock. All longer cases retain annual review choices before the horizon. Target price and fee settings survive duration changes, and observation moves to the selected end date.

All 89 Node tests pass. New coverage checks short-horizon accounting, valid review snapshots, same-time asset conservation, example paths that retain the first six months, and transitions between all five durations. Existing 3- and 5-year regression cases continue to pass. The English audit covers 555 rendered states with no missing templates.

Browser checks selected every duration, verified each timeline maximum, and confirmed the target was retained. One-year Review and Compare show Month 6; the comparison cursor at day 183 has zero instantaneous asset difference. Matching examples preserve the first six months, and both Chinese and English views render successfully.

## Preserved records and scope

The change extends supported time inputs and rounds the half-year decision to a whole day. Existing portfolio formulas, fee rates and real evidence are unchanged. No production source, AI archive or historical fee data was edited. The English materials package retains ten evidence excerpts, four structured records, six guides, a cover and a manifest, with hash and ZIP integrity validation.

Backup: versions/v0.24-before-five-horizons/. Public Netlify remains at v0.17; this update is local only.
