# CIRCLE case reference — v0.26

Verified September 17, 2026. This is presentation data for the interactive simulation, separate from archived research and monitored positions.

## Dated opening price

The walkthrough starts at **$92.02**, the CRCL (NYSE, USD) close for the **August 25, 2026 US trading session**. [Stock Analysis historical prices](https://stockanalysis.com/stocks/crcl/history/) lists Open 84.73, High 93.45, Low 84.25 and Close 92.02 for that session. The source describes historical data as adjusted for splits. The date refers to the US session, not a Beijing calendar date or a token pool snapshot.

The Plan page explains that this close is inside both starting LP ranges, without a separate price-source button. The source remains documented here. The price is frozen for a reproducible demonstration; it is not a live quote. The simulator assumes CRCLx follows the same USD price path as CRCL, without a token premium, discount or redemption friction.

## Relationship to historical research

The valuation baseline is the August 22, 2026 version for normalized 2027E operations. The August 24 archived AI proposal retains its original $88.53 reference and all original inputs, dates and evidence hashes. Neither record has been rewritten to use the later close.

The interactive case reuses that proposal's ranges and capital weights, then recalculates its opening share/cash quantities at $92.02. Its $10,000 buy-and-hold benchmark starts at the same price. This is a hypothetical reinitialization, not evidence of an actual August 25 trade or a fresh AI assessment.

At this opening price, both Core [58,172.95] and Active [90,115] are in range. Active must start with a funded mix of shares and cash; it cannot be treated as an all-share LP. Existing fee rules apply to each eligible LP's own capital.

## Duration, target and intervening price path

The Run page presents three independent inputs: how long to simulate, the target price assumed at the end, and how prices swing along the way. The target is an assumption, not an AI forecast. Number entry, valuation cards and the slider all update that same input.

| Visible path | Mechanism to explore |
|---|---|
| Volatile growth | Rallies and pullbacks, staged distribution and retained share exposure |
| Repeated swings | Repeated distribution, cash waiting and accumulation |
| Sustained pressure | Declines and rebounds, inventory losses and the limits of a fee cushion |

Selecting a path keeps the chosen target, duration and fee assumptions, replaces any loaded market example, and moves observation to the end. The final segment reaches the visitor’s chosen target, so even a pressure template can finish with a rebound. Horizons of 1, 2, 3, 4 and 5 years preserve the target. A one-year horizon reviews at month six (day 183). For 2–5 years, eligible review dates are year-ends before the horizon; changing duration retains a valid review date or moves it into that range. Changing the business thesis preserves the price path and opening reference; valuation zones change with the thesis.

The default remains a five-year repeated-swing case with a year-four company review. The Vault preview reuses the first year of this case, scaled to the entered capital. Archived analytical fixtures continue to use their original $88.53 start when no alternative opening price is supplied.

See [simulation methodology](SIMULATION_METHODS.md) for accounting and [AI workflow](AI_WORKFLOW.md) for the distinction between archived candidates and interactive calculations.

## Comparison examples and reset (v0.21)

The presets above replace the complete market path. The comparison/review pages additionally offer explicit examples that preserve market history through the review date and replace only the later segment. Both actions are labeled separately. The global reset restores five years, repeated swings, an $85 ending price, unchanged valuation and a year-four review; it clears drafts and previews without changing the language or evidence. See the simulation methodology for exact example construction.

## Fresh visits and a single path selector · v0.26

Each new document load or refresh starts at the overview with the default five-year, $85 repeated-swing case, even when the copied URL contains a step fragment. Restoring a cached document also starts a new case. The language query is retained; moving between steps or switching language inside the current document preserves the scenario. This demo intentionally favors a reproducible first visit over resuming a previous experiment.

Run it and Compare share all seven path templates and labels. The Run page uses one selector and a preview generated from the same price knots as the calculation engine. Duration and target remain independent. Loaded review examples have their own selected label until replaced. The settings drawer no longer contains a second price-path selector.

“Buy back and reopen LPs when conditions are met” controls repeated trading with available portfolio funds. Sale proceeds may buy shares at a pullback trigger and fund LPs again on recovery. When off, existing LPs finish at their exit conditions without reopening under the original rules. “Reinvest fees annually” separately controls earned fees: add them to eligible in-range LPs at year-end, or retain them as cash. A valuation revision follows its new allocation policy.

The next step is “Next: adjust valuation & positions.” It changes the valuation assumptions and allocation at the review date, while the market-price assumption remains independent.

 CIRCLE case reference — v0.25

Verified September 17, 2026. This is presentation data for the interactive simulation, separate from archived research and monitored positions.

## Dated opening price

The walkthrough starts at **$92.02**, the CRCL (NYSE, USD) close for the **August 25, 2026 US trading session**. [Stock Analysis historical prices](https://stockanalysis.com/stocks/crcl/history/) lists Open 84.73, High 93.45, Low 84.25 and Close 92.02 for that session. The source describes historical data as adjusted for splits. The date refers to the US session, not a Beijing calendar date or a token pool snapshot.

The Plan page explains that this close is inside both starting LP ranges, without a separate price-source button. The source remains documented here. The price is frozen for a reproducible demonstration; it is not a live quote. The simulator assumes CRCLx follows the same USD price path as CRCL, without a token premium, discount or redemption friction.

## Relationship to historical research

The valuation baseline is the August 22, 2026 version for normalized 2027E operations. The August 24 archived AI proposal retains its original $88.53 reference and all original inputs, dates and evidence hashes. Neither record has been rewritten to use the later close.

The interactive case reuses that proposal's ranges and capital weights, then recalculates its opening share/cash quantities at $92.02. Its $10,000 buy-and-hold benchmark starts at the same price. This is a hypothetical reinitialization, not evidence of an actual August 25 trade or a fresh AI assessment.

At this opening price, both Core [58,172.95] and Active [90,115] are in range. Active must start with a funded mix of shares and cash; it cannot be treated as an all-share LP. Existing fee rules apply to each eligible LP's own capital.

## Duration, target and intervening price path

The Run page presents three independent inputs: how long to simulate, the target price assumed at the end, and how prices swing along the way. The target is an assumption, not an AI forecast. Number entry, valuation cards and the slider all update that same input.

| Visible path | Mechanism to explore |
|---|---|
| Volatile growth | Rallies and pullbacks, staged distribution and retained share exposure |
| Repeated swings | Repeated distribution, cash waiting and accumulation |
| Sustained pressure | Declines and rebounds, inventory losses and the limits of a fee cushion |

Selecting a path keeps the chosen target, duration and fee assumptions, replaces any loaded market example, and moves observation to the end. The final segment reaches the visitor’s chosen target, so even a pressure template can finish with a rebound. Horizons of 1, 2, 3, 4 and 5 years preserve the target. A one-year horizon reviews at month six (day 183). For 2–5 years, eligible review dates are year-ends before the horizon; changing duration retains a valid review date or moves it into that range. Changing the business thesis preserves the price path and opening reference; valuation zones change with the thesis.

The default remains a five-year repeated-swing case with a year-four company review. The Vault preview reuses the first year of this case, scaled to the entered capital. Archived analytical fixtures continue to use their original $88.53 start when no alternative opening price is supplied.

See [simulation methodology](SIMULATION_METHODS.md) for accounting and [AI workflow](AI_WORKFLOW.md) for the distinction between archived candidates and interactive calculations.

## Comparison examples and reset (v0.21)

The presets above replace the complete market path. The comparison/review pages additionally offer explicit examples that preserve market history through the review date and replace only the later segment. Both actions are labeled separately. The global reset restores five years, repeated swings, an $85 ending price, unchanged valuation and a year-four review; it clears drafts and previews without changing the language or evidence. See the simulation methodology for exact example construction.
