# Future product previews — v0.16

Local review release, September 17, 2026. Public sites remain unchanged.

## Navigation

Try the strategy → Live evidence → AI & research → What's next. Live evidence links into AI & research, which now ends with a link into future product directions. The future landing page offers two secondary routes, `#vault` and `#agent`; both retain the What's next tab selection and a return button.

## Vault

1. Enter a hypothetical USDC amount, between 100 and 1,000,000. The preview assumes one USDC equals one dollar and an initial share NAV of $1. No wallet or contract is involved.
2. Inspect the inception receipt using CIRCLE's historical capital weights, reinitialized at the dated $92.02 demo start (see [case reference](DEMO_REFERENCE.md)). A separate year-one statement demonstrates attribution using the existing five-year repeated-cycle simulation. Holding return, static LP difference, management difference and accrued fees reconcile to total P&L. The report scales linearly with the preview capital; it does not claim actual vault performance. Trading friction, future management fees and withdrawal costs are excluded.
3. Explore the planned operating loop: eligible pool discovery, valuation review, constrained proposals, permission/preflight checks, execution, share accounting and reconciliation. Event controls explain routine range changes, material business changes and unverified news. DeFi adapters, withdrawal queues and remaining engineering work are available in disclosures.

## Self-custodial Agent

1. Specify an asset, amount and holding objective. CIRCLE has a historical template. Other symbols show a research onboarding checklist, without inventing valuation or LP parameters.
2. Inspect preset illustrative allocation targets. CIRCLE ranges come from the existing August 24 proposal; no fresh AI generation or optimization is claimed. Select manual confirmation or bounded Agent delegation, with a 5%, 10% or 20% per-action cap.
3. Try event handling. A hypothetical 8% routine allocation change waits for a signature in manual mode and is blocked by a 5% Agent cap. A sufficient cap only allows preflight, not unconditional execution. Material business changes require renewed review; unverified news stays under observation. Pause/resume and reset controls affect only the local preview. New assets remain gated on research and asset/pool verification.

## Implementation boundaries

`dist/future-preview.mjs` contains independent UI state, validation, reducers and bilingual rendering. `dist/future-preview.css` defines the responsive secondary-page layout. `dist/app-v2.mjs` connects forms, navigation and event buttons. No wallet SDK, remote model, new data API, deposit contract, signing method or transaction sender was added.

Product-preview state is preserved across in-app navigation and language switching, and resets on browser reload. It cannot change the main price simulation or operating-thesis draft. Raw form drafts are separate from submitted amounts and permissions. Archived records and the production system stay unchanged.

Backup: `versions/v0.13-before-product-previews/dist`.

## Validation

- The original preview release passed 54 tests, including report reconciliation and capital scaling, invalid amount/asset rejection, state isolation, research gating, manual versus Agent decisions, action limits, pause and permission reset.
- The original preview release audited 377 English rendered states with no missing translation templates.
- Browser checks covered Chinese and English flows, invalid deposits, receipt/report values, operation events, manual confirmation, Agent limits, pause/resume, research gating for a new symbol, and language-state preservation.
- Responsive checks used a 390 × 844 viewport and the normal desktop viewport. No horizontal overflow or browser console errors were observed in the new flows.
